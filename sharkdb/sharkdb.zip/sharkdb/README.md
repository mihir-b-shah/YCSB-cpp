# sharkdb
A LSM-based KV stored optimized for NVMe SSD.
